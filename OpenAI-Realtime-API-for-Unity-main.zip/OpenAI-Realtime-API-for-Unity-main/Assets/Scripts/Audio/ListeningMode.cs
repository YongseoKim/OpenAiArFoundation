public enum ListeningMode
{
    PushToTalk,
    VAD
}